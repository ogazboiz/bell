import { Component } from "react";

class Lang extends Component {
  render() {
    return (
      <select name="" id="">
        <option value=""></option>
      </select>
    );
  }
}
