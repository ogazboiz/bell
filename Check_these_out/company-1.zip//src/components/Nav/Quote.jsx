import { Component } from "react";
import Button from "../Global__Components/Button";
class Quote extends Component {
  render() {
    return <Button content="Get a Quote" />;
  }
}
export default Quote;
